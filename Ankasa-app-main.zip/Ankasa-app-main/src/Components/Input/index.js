import React from 'react'

const Input = ({...props}) => {
  return (
    <>
    <input  {...props} />
</>
  )
}

export default Input