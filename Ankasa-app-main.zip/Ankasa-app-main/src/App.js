import React, { Fragment } from 'react'
import Router from './Config/Router'
import './App.css'

const App = () => {
  return (
    <Fragment>
      <Router/>
    </Fragment>
  )
}

export default App
